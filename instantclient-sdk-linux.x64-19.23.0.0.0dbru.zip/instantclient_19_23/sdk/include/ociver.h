#ifndef OCIVER_ORACLE
#define OCIVER_ORACLE

#define OCI_MAJOR_VERSION 19             /* Feature release version */
#define OCI_MINOR_VERSION 23              /* Release update version */

#endif
